import os

class ScreenshotManager:

    @staticmethod
    async def capture(
            page,
            output_folder,
            transaction_name):

        file_name = os.path.join(
            output_folder,
            f"{transaction_name}.png"
        )

        await page.screenshot(
            path=file_name,
            full_page=True
        )

        return file_name