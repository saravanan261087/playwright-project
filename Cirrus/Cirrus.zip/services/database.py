import psycopg2
from config.settings import DB_CONFIG


class DatabaseService:

    @staticmethod
    def get_transaction(
            transaction_id):

        conn = psycopg2.connect(
            **DB_CONFIG
        )

        cursor = conn.cursor()

        cursor.execute("""
        SELECT *
        FROM cirrus.cirrus_operations
        WHERE "transactionId" = %s
        ORDER BY create_dt_ts DESC
        LIMIT 1
        """, (transaction_id,))

        row = cursor.fetchone()

        columns = [
            col[0]
            for col in cursor.description
        ]

        conn.close()

        return columns, row